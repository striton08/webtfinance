<?php

$conn = mysqli_connect('localhost','root','','personalfinancetracker') or die('connection failed');

?>